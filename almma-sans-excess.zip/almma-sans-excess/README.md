# almma-app
App for Almma's menu-picker app.
![image](https://github.com/user-attachments/assets/c32b74b8-2990-43e4-b85d-4db9b2b00f6c)

![image](https://github.com/user-attachments/assets/a3cfe74c-c21f-4995-bbaa-dcb55227c997)

